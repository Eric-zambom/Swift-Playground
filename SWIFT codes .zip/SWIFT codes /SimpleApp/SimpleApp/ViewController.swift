//
//  ViewController.swift
//  SimpleApp
//
//  Created by ERIC STICCHI ZAMBOM on 27/11/17.
//  Copyright © 2017 ERIC STICCHI ZAMBOM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fahrenheitLabel: UILabel!
    
    @IBOutlet weak var celsiusTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func convertToFahrenheit(_ sender: Any) {
        let celsius = Double(celsiusTextField.text!)
        let fahrenheit = (9 * celsius!) / 5 + 32
        fahrenheitLabel.text = String(fahrenheit)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


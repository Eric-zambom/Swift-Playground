//
//  Contact.swift
//  TableViewEx
//
//  Created by ERIC STICCHI ZAMBOM on 30/11/17.
//  Copyright © 2017 ERIC STICCHI ZAMBOM. All rights reserved.
//

import Foundation
import UIKit

// Contact Model
class Contact {
    var name: String?
    var lastName: String?
    var picture: UIImage?
    var email: String?
    var phoneNumber: Int?
}

//
//  ContactTableViewCell.swift
//  TableViewEx
//
//  Created by ERIC STICCHI ZAMBOM on 30/11/17.
//  Copyright © 2017 ERIC STICCHI ZAMBOM. All rights reserved.
//

import UIKit

class ContactTableViewCell: UITableViewCell {
    
    @IBOutlet weak var contactName: UILabel!
    @IBOutlet weak var contactImage: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

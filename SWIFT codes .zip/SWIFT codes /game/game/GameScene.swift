//
//  GameScene.swift
//  game
//
//  Created by ERIC STICCHI ZAMBOM on 04/12/17.
//  Copyright © 2017 ERIC STICCHI ZAMBOM. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    
    var label:SKLabelNode!
    var sprite:SKSpriteNode!
    
    var atlas:SKTextureAtlas!
    
    var previousTime:TimeInterval = 0
    var firstTime = true
    
    
    override func didMove(to view: SKView) {
        // :)
        scaleMode = .aspectFit
        backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        size = CGSize(width: 720, height: 1280)
        
        label = SKLabelNode.init(text: "Inertia Dorifto")
        addChild(label)
        
        label.fontColor = #colorLiteral(red: 0.01680417731, green: 0.1983509958, blue: 1, alpha: 1)
        label.position = CGPoint(x: size.width/2, y: -100)
        label.fontSize = 72
        label.zPosition = 1
        
        
        let action = SKAction.move(by: CGVector.init(dx: 0, dy: 60), duration: 1)
        let action2 = SKAction.repeatForever(action)
        label.run(action2)
        
        //let texture = SKTexture.init(imageNamed: "Trueno")
        atlas = SKTextureAtlas.init(named: "Imagens")
        sprite = SKSpriteNode.init(texture: atlas.textureNamed("FeelsBad"))
        addChild(sprite)
        
        sprite.position = CGPoint(x: size.width/2, y: size.height/2)
        sprite.size = CGSize(width: 300, height: 300)
        sprite.zPosition = -1
        
        let spriteList = [
            atlas.textureNamed("FeelsBad"),
            atlas.textureNamed("MartialDinamyte"),
            atlas.textureNamed("Trueno-1"),
        ]
        let spriteAction = SKAction.animate(with: spriteList, timePerFrame: 0.5)
        sprite.run(SKAction.repeatForever(spriteAction))
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // :)
        /*let deltaTime:CGFloat
        
        if firstTime {
            firstTime = false
            deltaTime = 1/60
        } else {
            deltaTime = CGFloat(currentTime-previousTime)
        }
        
        previousTime = currentTime
        
        //print(1/deltaTime)
        
        //label.position.y += deltaTime*60 */
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let pos = touch.location(in: self)
            
            let touchSprite = SKSpriteNode(texture: atlas.textureNamed("DeusVult"))
            addChild(touchSprite)
            touchSprite.position = pos
            
            if nodes(at: pos).contains(sprite) {
                touchSprite.color = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
                touchSprite.colorBlendFactor = 1
            }
            
            let action = SKAction.fadeOut(withDuration: 2)
            touchSprite.run(action, completion: {touchSprite.removeFromParent()
            })
        }
    }
}
